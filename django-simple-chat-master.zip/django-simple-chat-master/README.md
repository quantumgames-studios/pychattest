# django-simple-chat
Django simple chat
